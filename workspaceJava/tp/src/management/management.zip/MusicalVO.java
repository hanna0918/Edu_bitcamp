package management;
public class MusicalVO {
	private int s_code;
	private String s_title;
	private String s_cast;
	private String t_code;
	private String s_day;
	private String s_time;
	private String s_price;
	private String s_synop;
	private String s_grade;
	private String s_rtime;
	
	private String img;
	
	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public MusicalVO() {
	}

	public int getS_code() {
		return s_code;
	}

	public void setS_code(int s_code) {
		this.s_code = s_code;
	}

	public String getS_title() {
		return s_title;
	}

	public void setS_title(String s_title) {
		this.s_title = s_title;
	}

	public String getS_cast() {
		return s_cast;
	}

	public void setS_cast(String s_cast) {
		this.s_cast = s_cast;
	}

	public String getT_code() {
		return t_code;
	}

	public void setT_code(String t_code) {
		this.t_code = t_code;
	}

	public String getS_day() {
		return s_day;
	}

	public void setS_day(String s_day) {
		this.s_day = s_day;
	}

	public String getS_time() {
		return s_time;
	}

	public void setS_time(String s_time) {
		this.s_time = s_time;
	}

	public String getS_price() {
		return s_price;
	}

	public void setS_price(String s_price) {
		this.s_price = s_price;
	}

	public String getS_synop() {
		return s_synop;
	}

	public void setS_synop(String s_synop) {
		this.s_synop = s_synop;
	}

	public String getS_grade() {
		return s_grade;
	}

	public void setS_grade(String s_grade) {
		this.s_grade = s_grade;
	}

	public String getS_rtime() {
		return s_rtime;
	}

	public void setS_rtime(String s_rtime) {
		this.s_rtime = s_rtime;
	}

	public static void main(String[] args) {

	}

}
